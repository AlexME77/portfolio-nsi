import turtle
import aide
import formes
import random

def mur(x, y, hauteur):
    """
    Dessine le mur d'une maison.
    
    x       -- position x du coin inférieur gauche du mur
    y       -- position y du coin inférieur gauche du mur
    hauteur -- hauteur du mur
    """
    formes.rectangle(x, y, hauteur, 100)


def toit(x, y, hauteur):
    """
    Dessine le toit d'une maison.
    
    x       -- position x du coin inférieur gauche d'un toit
    y       -- position y du coin inférieur gauche d'un toit
    hauteur -- hauteur d'un toit
    """

    formes.triangle(x, y, 100, hauteur)

def porte(x, y, hauteur, largeur):
    """
    Dessine la porte de la maison.

    x       -- position x du coin inférieur gauche de la porte
    y       -- position y du coin inférieur gauche de la porte
    """
    
    formes.rectangle(x, y, hauteur, largeur)

def fenetre(x, y, cote):
    for i in range(2):
        formes.rectangle(x + cote*i, y, cote, cote)
        turtle.right(90)
        i+=1
    
    for i in range (2):
        formes.rectangle(x + cote*i, y + cote, cote, cote)
        turtle.right(90)
        i+=1


def maison(x, y, hauteur_mur, hauteur_toit, nb_etages, nb_fenetre):
    """
    Dessine une maison de 100px de largeur.

    x            -- position x du coin inférieur gauche de la maison
    y            -- position y du coin inférieur gauche de la maison
    hauteur_mur  -- hauteur d'un seul mur de la maison
    hauteur_toit -- hauteur du toit
    nb_etages    -- nombre d'étages de la maison, donc le  nombre de mur
    nb_fenetres  -- nombre de fenêtres de la maison
    """
    
    for i in range (nb_etages):
        mur(x, y + hauteur_mur*i, hauteur_mur)
        i+=1
        
    toit(x, y + hauteur_mur * nb_etages, hauteur_toit)
    
    porte(x + 100/2 - 20/2, y, hauteur_mur/3, 100/5)
    
    if nb_fenetre == 2:
        fenetre(x + 100/3 - hauteur_mur/10, y + hauteur_mur/2, hauteur_mur/10)
        fenetre(x + 2*(100/3) - hauteur_mur/10, y + hauteur_mur/2, hauteur_mur/10)
    elif nb_fenetre == 3:
        fenetre(x + 100/4 - hauteur_mur/10, y + hauteur_mur/2, hauteur_mur/10)
        fenetre(x + 2*(100/4) - hauteur_mur/10, y + hauteur_mur/2, hauteur_mur/10)
        fenetre(x + 3*(100/4) - hauteur_mur/10, y + hauteur_mur/2, hauteur_mur/10)
    else:
        fenetre(x + 100/2 - hauteur_mur/10, y + hauteur_mur/2, hauteur_mur/10)
    

    
def dessiner_paysage():
    """Dessine un paysage de 3 maisons sous Turtle."""
    maison(300, 0, 3)
    maison(0, 0, 2)
    maison(-300, 0, 4)


# Tests
if __name__ == "__main__":
    aide.grille()
    maison(0, 0, 75, 50, 2, 1)
    turtle.mainloop()
