import turtle
import aide

def position(x, y):
    """
    Positionne la tortue aux coordonnées (x, y).
    """
    turtle.penup()
    turtle.goto(x, y)
    turtle.pendown()

def triangle(x, y, base, hauteur):
    """
    Dessine un triangle.

    x       -- position x du coin inférieur gauche du triangle
    y       -- position y du coin inférieur gauche du triangle
    base    -- base du triangle
    hauteur -- hauteur du triangle
    """
    position(x, y)
    turtle.goto(x + base / 2, y + hauteur)
    turtle.goto(x + base, y)
    turtle.goto(x, y)

def rectangle(x, y, hauteur, largeur):
    """
    Dessine un rectangle
    x       -- position x du coin inférieur gauche du rectangle
    y       -- position y du coin inférieur gauche du rectangle
    largeur -- largeur du rectangle
    hauteur -- hauteur du rectangle
    """
    position(x, y)
    turtle.goto(x, y + hauteur)
    turtle.goto(x + largeur, y + hauteur )
    turtle.goto(x + largeur, y)
    turtle.goto(x, y)

def cercle(x, y, rayon):
    """
    Dessine un cercle

    x     -- position x du centre du cercle
    y     -- position y du centre du cercle
    rayon -- rayon du cercle
    """
    position(x, y)
    turtle.circle(rayon)

# Tests
if __name__ == "__main__":
    aide.grille()
    rectangle(0, 0, 100, 100)
    triangle(0, 100, 100, 50)
    rectangle(30, 0, 40, 20)
    cercle(47, 20, 3)
    turtle.mainloop()